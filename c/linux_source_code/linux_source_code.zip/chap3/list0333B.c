// list0333B.c
extern double sin (double);

int
main ()
{
  double x = sin (0.0);
  return 0;
}

