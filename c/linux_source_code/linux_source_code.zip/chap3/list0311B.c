// list0311B.c
#include <stdio.h>

void
function2 ()
{
  printf ("Hello from function No.2\n");
}

int
main ()
{
  function1();
  function2();
  return 0;
}

