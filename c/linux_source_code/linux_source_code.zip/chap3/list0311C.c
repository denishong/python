// list0311C.c
#include <stdio.h>

void
function1 ()
{
  printf ("Hello from function No.1 !!!\n");
}

