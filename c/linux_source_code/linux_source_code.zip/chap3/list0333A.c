// list0333A.c
int
main ()
{
  double x = sin (0.0);
  return 0;
}

