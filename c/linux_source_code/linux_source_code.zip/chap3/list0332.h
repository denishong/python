// list0332.h
extern
void
function1 ();

