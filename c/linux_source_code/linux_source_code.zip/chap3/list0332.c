// list0332.c
#include "list0332.h"

int
main ()
{
  return 0;
}

