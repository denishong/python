#!/bin/sh
gcc list0311A.c -c
gcc list0311B.c -c
gcc list0311A.o list0311B.o -o list0311

