// list0333C.c
#include <math.h>

int
main ()
{
  double x = sin (0.0);
  return 0;
}

