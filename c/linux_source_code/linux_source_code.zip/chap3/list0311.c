// list0311.c
#include <stdio.h>

void
function1 ()
{
  printf ("Hello from function No.1\n");
}

void
function2 ()
{
  printf ("Hello from function No.2\n");
}

int
main ()
{
  function1();
  function2();
  return 0;
}

