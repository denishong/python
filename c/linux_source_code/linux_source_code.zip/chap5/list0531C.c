// list0531C.c
#include <stdio.h>

static int a;
int b;

int
main ()
{
  a = 1;
  b = 2;
  printf ("a+b = %d\n", a+b);
  return 0;
}

