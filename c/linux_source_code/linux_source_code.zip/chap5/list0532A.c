// list0532A.c
#include <stdio.h>

void
func1 ()
{
  printf ("Hello, world (1)\n");
}

int
main ()
{
  func1 ();
  return 0;
}

