// list0532B.c
#include <stdio.h>

void
func1 ()
{
  printf ("Hello, world (2)\n");
}

void
func2 ()
{
  func1 ();
}

