// list0431B.c
#include <stdio.h>
void
function2 ()
{
  printf ("Hello from function No.2\n");
}

