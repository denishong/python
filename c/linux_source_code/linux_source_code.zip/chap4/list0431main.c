// list0431main.c
#include "list0431A.h"
#include "list0431B.h"

int
main ()
{
  function1 ();
  function2 ();
  return 0;
}

