// list0431B.h
extern void function2 ();

