#ifndef __CVX_EDGE_SORTER_H__
#define __CVX_EDGE_SORTER_H__
#include <gtk/gtk.h>

G_BEGIN_DECLS

GList*  cvx_edge_sorter_sort_list (GList* list);

G_END_DECLS

#endif // __CVX_EDGE_SORTER_H__

