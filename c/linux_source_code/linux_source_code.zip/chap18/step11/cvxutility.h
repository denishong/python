#ifndef __CVX_UTILITY_H__
#define __CVX_UTILITY_H__
#include <gtk/gtk.h>

G_BEGIN_DECLS

double  cvx_utility_calc_angle (double v0_x, double v0_y,
                                double v1_x, double v1_y);

G_END_DECLS

#endif // __CVX_UTILITY_H__

