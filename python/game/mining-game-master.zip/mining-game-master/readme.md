mining-game
===========

You're a miner hunting treasure.  How much treasure can you gather before your strength runs out?

arrow keys: change miner's direction
space: mine block

The brightness of a block indicates it's strenth -- brighter is stronger.
Outlines around the blocks indicate a better chance of treasure.